<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//Yellowbot API Key
$config['api_key'] = "c7cbf3afd2cedd3c69cd091a8f2e7347";
//$config['api_key'] = "59667cf953f4c37f0d760c003a287972";
//Yellowbot API Secret
$config['api_secret'] = "66f4cdbbd65cb13a";
//$config['api_secret'] = "f89d48e031440891";

//Payment Processing Service URL
//PROD
//$config['payment_service_url'] =  "https://www.ubl.org/payment.svc";
//QA
$config['payment_service_url'] =  "https://qa.ubl.org/payment.svc";

//Default Price
$config['default_price'] = '19.95';

//Default Frequency
$config['default_frequency'] = "12";

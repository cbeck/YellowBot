<?php
include('static/'.$uri.'.php');
?>
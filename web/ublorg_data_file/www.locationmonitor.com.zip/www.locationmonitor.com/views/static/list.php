<html>
<head>
  <title>LocationMonitor.com - List your business</title>
  <?php include(dirname(__FILE__)."/../includes/doc_head.inc"); ?>
</head>
<body>
  <div id="canvas" class="container_12">
    <?php include(dirname(__FILE__)."/../includes/header.inc"); ?>
    <div id="main" class="container_12">
      <h2>List your business</h2>
    </div>
    <?php include(dirname(__FILE__)."/../includes/footer.inc"); ?>  
  </div>
</body>
</html>